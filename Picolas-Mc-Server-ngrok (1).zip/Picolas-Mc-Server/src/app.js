const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const http = require("http");
const { WebSocketServer } = require("ws");
const { spawn, execSync } = require("child_process");
const axios = require("axios");
const si = require("systeminformation");
const ngrok = require("ngrok");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, "..");
const SERVERS_DIR = path.join(ROOT, "servers");
const DATA_DIR = path.join(ROOT, "data");
const DOWNLOADS_DIR = path.join(ROOT, "downloads");
const SERVERS_FILE = path.join(DATA_DIR, "servers.json");
const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const PLUGINS_FILE = path.join(DATA_DIR, "plugins.json");

app.use(cors());
app.use(express.json({ limit: "15mb" }));
app.use(express.static(path.join(ROOT, "public")));

const running = new Map();
const ngrokTunnels = new Map();

function ensure() {
  for (const dir of [SERVERS_DIR, DATA_DIR, DOWNLOADS_DIR, path.join(DOWNLOADS_DIR, "jars"), path.join(DOWNLOADS_DIR, "plugins")]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(SERVERS_FILE)) fs.writeFileSync(SERVERS_FILE, "[]", "utf8");
  if (!fs.existsSync(SETTINGS_FILE)) fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ configured: true, ngrok: { enabled: false, authtoken: "", region: "us", autoStart: true } }, null, 2));
}
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; } }
function writeJson(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8"); }
function listServers() { return readJson(SERVERS_FILE, []); }
function saveServers(data) { writeJson(SERVERS_FILE, data); }
function settings() { return readJson(SETTINGS_FILE, { configured: true, ngrok: { enabled: false, authtoken: "", region: "us", autoStart: true } }); }
function safeName(name) { return String(name || "server").trim().replace(/[^a-zA-Z0-9-_]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").toLowerCase() || `server-${Date.now()}`; }
function serverPath(id) { return path.join(SERVERS_DIR, id); }
function broadcast(type, payload) { const msg = JSON.stringify({ type, payload }); wss.clients.forEach(c => { if (c.readyState === 1) c.send(msg); }); }
function pushLog(id, line) {
  const item = running.get(id);
  if (!item) return;
  item.logs.push(line);
  if (item.logs.length > 1000) item.logs.shift();
  broadcast("log", { id, line });
}
function writeServerProperties(file, cfg) {
  const lines = [
    `server-port=${cfg.port || 25565}`,
    `online-mode=${cfg.cracked ? "false" : "true"}`,
    `motd=${cfg.motd || cfg.name || "Picolas-Mc-Server"}`,
    `max-players=${cfg.maxPlayers || 20}`,
    `white-list=${cfg.whitelist ? "true" : "false"}`,
    `difficulty=${cfg.difficulty || "normal"}`,
    `gamemode=${cfg.gamemode || "survival"}`,
    `enable-command-block=${cfg.commandBlocks ? "true" : "false"}`,
    `spawn-protection=0`,
    `view-distance=8`,
    `simulation-distance=6`
  ];
  fs.writeFileSync(file, lines.join("\n") + "\n", "utf8");
}
async function downloadFile(url, dest) {
  const response = await axios.get(url, { responseType: "stream", timeout: 120000 });
  await new Promise((resolve, reject) => {
    const writer = fs.createWriteStream(dest);
    response.data.pipe(writer);
    writer.on("finish", resolve);
    writer.on("error", reject);
  });
}
async function downloadPaper(version, dest) {
  const buildInfo = await axios.get(`https://api.papermc.io/v2/projects/paper/versions/${version}/builds`, { timeout: 30000 });
  const builds = buildInfo.data.builds || [];
  if (!builds.length) throw new Error(`No hay builds de Paper para ${version}`);
  const latest = builds[builds.length - 1];
  const jarName = latest.downloads.application.name;
  const url = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${latest.build}/downloads/${jarName}`;
  await downloadFile(url, dest);
  return { build: latest.build, jarName };
}
async function downloadVanilla(version, dest) {
  const manifest = await axios.get("https://launchermeta.mojang.com/mc/game/version_manifest.json", { timeout: 30000 });
  const item = manifest.data.versions.find(v => v.id === version);
  if (!item) throw new Error(`Versión vanilla no encontrada: ${version}`);
  const versionJson = await axios.get(item.url, { timeout: 30000 });
  const url = versionJson.data.downloads.server.url;
  await downloadFile(url, dest);
  return { jarName: `vanilla-${version}.jar` };
}
async function installModrinthPlugin(srv, plugin) {
  const url = `https://api.modrinth.com/v2/project/${plugin.slug}/version?loaders=[%22paper%22]&game_versions=[%22${srv.version}%22]`;
  const res = await axios.get(url, { timeout: 30000, headers: { "User-Agent": "Picolas-Mc-Server/2.0" } });
  const versions = Array.isArray(res.data) ? res.data : [];
  if (!versions.length) throw new Error(`No encontré versión compatible de ${plugin.name} para ${srv.version}`);
  const primary = versions[0].files.find(f => f.primary) || versions[0].files[0];
  if (!primary?.url) throw new Error(`El plugin ${plugin.name} no tiene descarga disponible`);
  const pluginsDir = path.join(serverPath(srv.id), "plugins");
  if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
  const dest = path.join(pluginsDir, primary.filename || `${plugin.slug}.jar`);
  await downloadFile(primary.url, dest);
  return path.basename(dest);
}
async function startNgrokForServer(srv) {
  const cfg = settings().ngrok || {};
  if (!cfg.enabled || !cfg.authtoken) return null;
  if (ngrokTunnels.has(srv.id)) return ngrokTunnels.get(srv.id);
  try {
    const url = await ngrok.connect({ proto: "tcp", addr: Number(srv.port || 25565), authtoken: cfg.authtoken, region: cfg.region || "us" });
    ngrokTunnels.set(srv.id, url);
    const all = listServers();
    const idx = all.findIndex(s => s.id === srv.id);
    if (idx >= 0) { all[idx].publicUrl = url; saveServers(all); }
    pushLog(srv.id, `\n[NGROK] Túnel activo: ${url}\n`);
    broadcast("servers", await getServersEnriched());
    return url;
  } catch (e) {
    pushLog(srv.id, `\n[NGROK ERROR] ${e.message}\n`);
    return null;
  }
}
async function getServersEnriched() {
  const arr = listServers();
  return arr.map(s => ({ ...s, running: running.has(s.id), publicUrl: ngrokTunnels.get(s.id) || s.publicUrl || "" }));
}
function parsePlayerLog(id, line) {
  const r = running.get(id);
  if (!r) return;
  let m = line.match(/([A-Za-z0-9_]{3,16})\[\/([^:\]]+):\d+\] logged in/);
  if (m) {
    r.players.set(m[1], { name: m[1], ip: m[2], status: "Online", ping: "?", uuid: `runtime-${m[1]}` });
    broadcast("players", { id, players: Array.from(r.players.values()) });
  }
  m = line.match(/([A-Za-z0-9_]{3,16}) left the game/);
  if (m && r.players.has(m[1])) {
    const p = r.players.get(m[1]); p.status = "Offline";
    broadcast("players", { id, players: Array.from(r.players.values()) });
  }
}
function javaVersionText() { try { return execSync("java -version 2>&1", { encoding: "utf8" }); } catch { return "Java no encontrado"; } }

ensure();

app.get("/api/health", (req, res) => res.json({ ok: true, java: javaVersionText() }));
app.get("/api/settings", (req, res) => {
  const s = settings();
  res.json({ ...s, ngrok: { ...s.ngrok, authtoken: s.ngrok?.authtoken ? "********" : "" } });
});
app.post("/api/settings/ngrok", (req, res) => {
  const s = settings();
  s.ngrok = { enabled: !!req.body.enabled, authtoken: req.body.authtoken && req.body.authtoken !== "********" ? req.body.authtoken : (settings().ngrok?.authtoken || ""), region: req.body.region || "us", autoStart: req.body.autoStart !== false };
  s.configured = true;
  writeJson(SETTINGS_FILE, s);
  res.json({ ok: true });
});
app.get("/api/servers", async (req, res) => res.json(await getServersEnriched()));
app.get("/api/plugins", (req, res) => res.json(readJson(PLUGINS_FILE, [])));
app.get("/api/paper/versions", async (req, res) => {
  try {
    const r = await axios.get("https://api.papermc.io/v2/projects/paper", { timeout: 30000 });
    res.json((r.data.versions || []).reverse().slice(0, 30));
  } catch { res.json(["1.21.4", "1.21.1", "1.20.6", "1.20.4", "1.19.4"]); }
});
app.post("/api/servers/create", async (req, res) => {
  try {
    const b = req.body || {};
    const id = safeName(b.name);
    const dir = serverPath(id);
    if (fs.existsSync(dir)) return res.status(400).json({ error: "Ya existe un servidor con ese nombre." });
    fs.mkdirSync(dir, { recursive: true });
    fs.mkdirSync(path.join(dir, "plugins"), { recursive: true });
    fs.mkdirSync(path.join(dir, "logs"), { recursive: true });

    const srv = {
      id,
      name: b.name || id,
      description: b.description || "",
      imageData: b.imageData || "",
      type: b.type || "paper",
      version: b.version || "1.21.4",
      port: Number(b.port || 25565),
      ram: Number(b.ram || 2048),
      maxPlayers: Number(b.maxPlayers || 20),
      cracked: !!b.cracked,
      whitelist: !!b.whitelist,
      eula: !!b.eula,
      adminUser: b.adminUser || "",
      difficulty: b.difficulty || "normal",
      gamemode: b.gamemode || "survival",
      createdAt: new Date().toISOString(),
      publicUrl: ""
    };
    if (!srv.eula) return res.status(400).json({ error: "Tenés que aceptar la EULA para crear el servidor." });
    fs.writeFileSync(path.join(dir, "eula.txt"), "eula=true\n", "utf8");
    writeServerProperties(path.join(dir, "server.properties"), srv);
    writeJson(path.join(dir, "server-info.json"), srv);
    writeJson(path.join(dir, "ops.json"), []);
    writeJson(path.join(dir, "whitelist.json"), []);
    writeJson(path.join(dir, "banned-players.json"), []);
    writeJson(path.join(dir, "banned-ips.json"), []);

    const jar = path.join(dir, "server.jar");
    if (srv.type === "paper") await downloadPaper(srv.version, jar);
    else if (srv.type === "vanilla") await downloadVanilla(srv.version, jar);
    else fs.writeFileSync(path.join(dir, "LEEME_BEDROCK.txt"), "Bedrock todavía queda en modo manual. Usá Java Paper + Geyser para aceptar Bedrock.\n", "utf8");

    const all = listServers(); all.push(srv); saveServers(all);

    const selected = Array.isArray(b.plugins) ? b.plugins : [];
    const pluginList = readJson(PLUGINS_FILE, []);
    const installed = [];
    if (srv.type === "paper" && selected.length) {
      for (const name of selected) {
        const plug = pluginList.find(p => p.name === name);
        if (!plug) continue;
        try { installed.push(await installModrinthPlugin(srv, plug)); } catch (e) { installed.push(`${plug.name}: ERROR ${e.message}`); }
      }
    }
    res.json({ ok: true, server: srv, installedPlugins: installed });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
app.post("/api/servers/:id/start", async (req, res) => {
  const id = req.params.id;
  const srv = listServers().find(s => s.id === id);
  if (!srv) return res.status(404).json({ error: "Servidor no encontrado" });
  if (running.has(id)) return res.status(400).json({ error: "El servidor ya está iniciado" });
  const dir = serverPath(id);
  const jar = path.join(dir, "server.jar");
  if (!fs.existsSync(jar)) return res.status(400).json({ error: "Falta server.jar. Descargá Paper/Vanilla o ponelo manualmente." });
  const args = [`-Xmx${srv.ram || 2048}M`, `-Xms${Math.min(512, srv.ram || 2048)}M`, "-jar", "server.jar", "nogui"];
  const p = spawn("java", args, { cwd: dir, shell: true });
  running.set(id, { process: p, logs: [], players: new Map(), startedAt: Date.now(), pid: p.pid });
  pushLog(id, `[Picolas] Iniciando ${srv.name} con Java...\n`);
  p.stdout.on("data", d => { const text = d.toString(); pushLog(id, text); parsePlayerLog(id, text); });
  p.stderr.on("data", d => { const text = d.toString(); pushLog(id, text); parsePlayerLog(id, text); });
  p.on("close", async code => {
    pushLog(id, `\n[Picolas] Servidor cerrado con código ${code}\n`);
    running.delete(id);
    if (ngrokTunnels.has(id)) { try { await ngrok.disconnect(ngrokTunnels.get(id)); } catch {} ngrokTunnels.delete(id); }
    broadcast("servers", await getServersEnriched());
  });
  const cfg = settings().ngrok || {};
  if (cfg.enabled && cfg.autoStart) startNgrokForServer(srv);
  broadcast("servers", await getServersEnriched());
  res.json({ ok: true });
});
app.post("/api/servers/:id/stop", async (req, res) => {
  const r = running.get(req.params.id);
  if (!r) return res.status(400).json({ error: "No está iniciado" });
  r.process.stdin.write("stop\n");
  res.json({ ok: true });
});
app.post("/api/servers/:id/command", (req, res) => {
  const r = running.get(req.params.id);
  if (!r) return res.status(400).json({ error: "Servidor apagado" });
  const cmd = String(req.body.command || "").trim();
  if (!cmd) return res.status(400).json({ error: "Comando vacío" });
  r.process.stdin.write(cmd + "\n");
  pushLog(req.params.id, `\n> ${cmd}\n`);
  res.json({ ok: true });
});
app.post("/api/servers/:id/ngrok/start", async (req, res) => {
  const srv = listServers().find(s => s.id === req.params.id);
  if (!srv) return res.status(404).json({ error: "Servidor no encontrado" });
  const url = await startNgrokForServer(srv);
  if (!url) return res.status(400).json({ error: "No se pudo iniciar ngrok. Revisá authtoken/configuración." });
  res.json({ ok: true, url });
});
app.get("/api/servers/:id/logs", (req, res) => res.json({ logs: running.get(req.params.id)?.logs || ["Servidor apagado."] }));
app.get("/api/servers/:id/players", (req, res) => res.json({ players: Array.from(running.get(req.params.id)?.players.values() || []) }));
app.post("/api/servers/:id/player-action", (req, res) => {
  const { action, player, ip } = req.body;
  const map = { kick: `kick ${player}`, ban: `ban ${player}`, banip: `ban-ip ${ip || player}`, op: `op ${player}`, deop: `deop ${player}`, wadd: `whitelist add ${player}`, wremove: `whitelist remove ${player}` };
  const command = map[action];
  if (!command) return res.status(400).json({ error: "Acción inválida" });
  const r = running.get(req.params.id);
  if (!r) return res.status(400).json({ error: "Servidor apagado" });
  r.process.stdin.write(command + "\n");
  res.json({ ok: true, command });
});
app.post("/api/servers/:id/plugins/install", async (req, res) => {
  try {
    const srv = listServers().find(s => s.id === req.params.id);
    if (!srv) return res.status(404).json({ error: "Servidor no encontrado" });
    const plugin = readJson(PLUGINS_FILE, []).find(p => p.name === req.body.name);
    if (!plugin) return res.status(404).json({ error: "Plugin no encontrado" });
    const file = await installModrinthPlugin(srv, plugin);
    res.json({ ok: true, file });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/api/servers/:id/plugins/install-url", async (req, res) => {
  try {
    const url = String(req.body.url || "").trim();
    if (!/^https?:\/\/.+\.jar(\?.*)?$/i.test(url)) return res.status(400).json({ error: "Pegá una URL directa a un .jar" });
    const pluginsDir = path.join(serverPath(req.params.id), "plugins");
    if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });
    const file = path.basename(url.split("?")[0]).replace(/[^a-zA-Z0-9._-]/g, "_");
    await downloadFile(url, path.join(pluginsDir, file));
    res.json({ ok: true, file });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get("/api/servers/:id/files", (req, res) => {
  const rel = String(req.query.path || "");
  const base = serverPath(req.params.id);
  const target = path.normalize(path.join(base, rel));
  if (!target.startsWith(base)) return res.status(403).json({ error: "Ruta inválida" });
  const items = fs.readdirSync(target, { withFileTypes: true }).map(d => ({ name: d.name, dir: d.isDirectory() }));
  res.json({ path: rel, items });
});
app.get("/api/servers/:id/file", (req, res) => {
  const base = serverPath(req.params.id);
  const target = path.normalize(path.join(base, String(req.query.path || "")));
  if (!target.startsWith(base) || !fs.existsSync(target) || fs.statSync(target).isDirectory()) return res.status(400).json({ error: "Archivo inválido" });
  if (fs.statSync(target).size > 1024 * 1024) return res.status(400).json({ error: "Archivo demasiado grande" });
  res.json({ content: fs.readFileSync(target, "utf8") });
});
app.post("/api/servers/:id/file", (req, res) => {
  const base = serverPath(req.params.id);
  const target = path.normalize(path.join(base, String(req.body.path || "")));
  if (!target.startsWith(base)) return res.status(403).json({ error: "Ruta inválida" });
  fs.writeFileSync(target, String(req.body.content || ""), "utf8");
  res.json({ ok: true });
});
app.get("/api/servers/:id/stats", async (req, res) => {
  const srv = listServers().find(s => s.id === req.params.id);
  const r = running.get(req.params.id);
  const cpu = await si.currentLoad();
  const mem = await si.mem();
  const fsSize = await si.fsSize();
  let proc = null;
  if (r?.pid) {
    const ps = await si.processes();
    proc = ps.list.find(p => p.pid === r.pid) || null;
  }
  res.json({
    server: srv,
    running: !!r,
    uptime: r ? Date.now() - r.startedAt : 0,
    players: r ? Array.from(r.players.values()).filter(p => p.status === "Online").length : 0,
    cpu: cpu.currentLoad,
    memUsed: mem.active,
    memTotal: mem.total,
    disk: fsSize[0] || null,
    process: proc,
    ngrok: ngrokTunnels.get(req.params.id) || srv?.publicUrl || ""
  });
});

server.listen(PORT, () => {
  console.log(`\n✅ Picolas-Mc-Server iniciado`);
  console.log(`🌐 Panel: http://localhost:${PORT}`);
  console.log(`📌 En Codespaces abrí el puerto ${PORT} desde la pestaña Ports.\n`);
});
