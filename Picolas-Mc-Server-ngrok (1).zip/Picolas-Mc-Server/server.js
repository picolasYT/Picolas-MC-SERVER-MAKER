#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const readline = require("readline");

const root = __dirname;
const dataDir = path.join(root, "data");
const settingsFile = path.join(dataDir, "settings.json");
const packageFile = path.join(root, "package.json");

function ensureBaseFolders() {
  for (const dir of ["data", "servers", "downloads", "downloads/jars", "downloads/plugins"]) {
    const full = path.join(root, dir);
    if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
  }
  const serversFile = path.join(dataDir, "servers.json");
  if (!fs.existsSync(serversFile)) fs.writeFileSync(serversFile, "[]", "utf8");
}

function needInstall() {
  const pkg = JSON.parse(fs.readFileSync(packageFile, "utf8"));
  const deps = Object.keys(pkg.dependencies || {});
  return deps.some(dep => !fs.existsSync(path.join(root, "node_modules", dep)));
}

function installDependencies() {
  console.log("\n📦 Verificando dependencias...");
  if (!needInstall()) {
    console.log("✅ Dependencias OK");
    return;
  }
  console.log("⬇️ Instalando dependencias automáticamente con npm install...");
  const result = spawnSync("npm", ["install"], { cwd: root, stdio: "inherit", shell: true });
  if (result.status !== 0) {
    console.error("❌ No se pudieron instalar las dependencias. Ejecutá: npm install");
    process.exit(1);
  }
  console.log("✅ Dependencias instaladas");
}

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, answer => { rl.close(); resolve(answer.trim()); }));
}

async function firstConfig() {
  if (fs.existsSync(settingsFile)) return;

  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("⛏️  Bienvenido a Picolas-Mc-Server");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("Este panel puede publicar tu server con ngrok TCP.");
  console.log("Necesitás una cuenta de ngrok y pegar tu authtoken.");
  console.log("Podés saltarlo y configurarlo luego desde el panel.\n");

  const enabledAns = await ask("¿Configurar ngrok ahora? (s/n): ");
  const enabled = ["s", "si", "sí", "y", "yes"].includes(enabledAns.toLowerCase());

  let authtoken = "";
  let region = "us";
  let autoStart = true;

  if (enabled) {
    authtoken = await ask("Pegá tu ngrok authtoken: ");
    const regionAns = await ask("Región ngrok [us/eu/ap/au/sa/jp/in] (enter = us): ");
    region = regionAns || "us";
    const autoAns = await ask("¿Iniciar túnel automáticamente al iniciar un server? (s/n, enter = s): ");
    autoStart = !["n", "no"].includes(autoAns.toLowerCase());
  }

  const settings = {
    configured: true,
    ngrok: { enabled, authtoken, region, autoStart }
  };

  fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2), "utf8");
  console.log("✅ Configuración guardada\n");
}

(async () => {
  ensureBaseFolders();
  installDependencies();
  await firstConfig();
  require("./src/app");
})();
