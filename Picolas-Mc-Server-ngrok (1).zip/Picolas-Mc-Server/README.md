# Picolas-Mc-Server

Panel local para crear servidores Minecraft Java, administrar consola, jugadores, plugins y publicar con ngrok TCP.

## Iniciar

```bash
node server.js
```

El primer inicio instala dependencias y te pregunta si querés configurar ngrok.

## En GitHub Codespaces

1. Abrí terminal.
2. Ejecutá:
   ```bash
   node server.js
   ```
3. Pegá tu authtoken de ngrok cuando lo pida.
4. Abrí el puerto web 3000 desde la pestaña Ports.
5. Creá un server Paper y luego iniciá.

## Java

Minecraft 1.19+ necesita Java 17 o superior. Minecraft 1.20.5+ / 1.21+ se recomienda Java 21.

En Codespaces podés instalar Java 21 con:

```bash
sudo apt update
sudo apt install -y openjdk-21-jdk
java -version
```
